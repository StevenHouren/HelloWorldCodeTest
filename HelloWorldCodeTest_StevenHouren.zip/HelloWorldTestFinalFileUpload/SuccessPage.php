<!DOCTYPE html>
<html>
<head>
    <title>Success Page</title>

<style type=text/css>

body{

background-color: #151515;
color: white;
font-family: Helvetica;
margin: 0 auto;   
margin-top: 100px;
}

.SuccessMessage{
    text-align: center;
    max-width: 500px;
    margin: auto;
}

</style>

</head>
<body>
<div class="SuccessMessage">
<h1>Congratulations!  Your registration was successful.</h1>

<p>To register another user account please click the back button below.</p>

<a href="UserRegistration.php"><button type="button">Back</button></a>

</div>

</body>
</html>