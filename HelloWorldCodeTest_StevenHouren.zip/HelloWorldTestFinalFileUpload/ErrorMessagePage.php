<!DOCTYPE html>
<html>
<head>
    <title>Error Page</title>

<style type=text/css>

body{

background-color: #151515;
color: white;
font-family: Helvetica;
margin: 0 auto;   
margin-top: 100px;
}

.ErrorMessage{
    text-align: center;
    max-width: 500px;
    margin: auto;
}

</style>

</head>
<body>

<div class="ErrorMessage">
<h1>Oh no!  Your registration was not successful.</h1>

<p>To try again please click the back button below.</p>

<a href="UserRegistration.php"><button type="button">Back</button></a>

</div>

</body>
</html>